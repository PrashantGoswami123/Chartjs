<!DOCTYPE html>
<html>
<head>
<title>Line Chart</title>
<meta name="viewport" content="width=device-width initial-scale=1.0"/>
<meta name="author" content="Prashant Goswami"/>
<meta http-equiv="X-UA-Compatible" content="ie=edge"> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
</head>
<body>
<div class="container" >
<canvas id="chart" >  </canvas>
</div>
<?php
$con=mysqli_connect('localhost','root','','data');
for($i=1;$i<=12;$i++){
$q="select * from datacollection where id='$i'";
$x=mysqli_query($con,$q);
$arr=mysqli_fetch_assoc($x);
$a[$i]=$arr['Budget'];
}
?>
<script>
let chart=document.getElementById("chart").getContext('2d');



let chart1=new Chart(chart,{
   type:'bar',
     data:{
	 labels:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
	 datasets:[{
	 label:'Budget',
	 data:[
	 <?php for($i=1;$i<=11;$i++)
	 {
		 echo "$a[$i],";
	 }echo $a[12];
	 ?>
	 ],
	          backgroundColor:[
            'rgba(155, 220, 132, 0.8)',
            'rgba(54, 162, 235, 0.8)',
            'rgba(255, 206, 86, 0.8)',
            'rgba(75, 192, 192, 0.8)',
            'rgba(153, 102, 255, 0.8)',
            'rgba(255, 159, 64, 0.8)',
            'rgba(255, 99, 132, 0.8)',
			'rgba(255, 104, 132, 0.8)',
			'rgba(105, 104, 132, 0.8)',
			'rgba(155, 124, 120, 0.8)',
			'rgba(240, 164, 232, 0.8)',
			'rgba(155, 144, 32, 0.8)'
			
          ],	   borderWidth:1,
          borderColor:'#777',
          hoverBorderWidth:3,
          hoverBorderColor:'#000'// backgroundColor:'red'
     }]
	  },    options:{
        title:{
          display:true,
          text:'Budget',
          fontSize:25
        },
        legend:{
          display:true,
          position:'right',
          labels:{
            fontColor:'#000'
          }
        },
        layout:{
          padding:{
            left:50,
            right:0,
            bottom:0,
            top:0
          }
        },
        tooltips:{
          enabled:true
        }
      }   });


</script>
</body>
</html>