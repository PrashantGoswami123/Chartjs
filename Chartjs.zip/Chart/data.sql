-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 26, 2019 at 11:29 AM
-- Server version: 5.7.24
-- PHP Version: 7.2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `data`
--

-- --------------------------------------------------------

--
-- Table structure for table `datacollection`
--

DROP TABLE IF EXISTS `datacollection`;
CREATE TABLE IF NOT EXISTS `datacollection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Months` varchar(255) NOT NULL,
  `Budget` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Months` (`Months`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `datacollection`
--

INSERT INTO `datacollection` (`id`, `Months`, `Budget`) VALUES
(1, 'Jan', 60000),
(2, 'Feb', 56789),
(3, 'Mar', 49765),
(4, 'Apr', 44234),
(5, 'May', 39567),
(6, 'Jun', 34987),
(7, 'Jul', 29765),
(8, 'Aug', 24432),
(9, 'Sep', 19876),
(10, 'Oct', 14897),
(11, 'Nov', 11765),
(12, 'Dec', 6890);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
